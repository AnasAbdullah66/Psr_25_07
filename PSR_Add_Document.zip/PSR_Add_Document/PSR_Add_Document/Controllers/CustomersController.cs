﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Runtime.Intrinsics.Arm;
using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using PSR_Add_Document.Models;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using NuGet.Protocol;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using System.IO;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using SixLabors.ImageSharp.Formats.Jpeg;
using PdfSharpCore.Pdf;
using PdfSharpCore.Drawing;
using PdfSharpCore.Pdf.IO;
using static System.Net.WebRequestMethods;
using System.Net.Sockets;
using System.Drawing;
using System.Text;
using System.Xml;
using System.Security.Cryptography;
using System.Xml.Linq;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using PSR_Add_Document.ViewModel;
using Humanizer;
using PdfSharpCore.Pdf.Content.Objects;

namespace PSR_Add_Document.Controllers
{
    public class CustomersController : Controller
    {
        private readonly CustomerDbContext _context;
        private readonly IConfiguration _configuration;
        private IWebHostEnvironment environment;

        // SessionCustomer 

        public const string SessionAccountNo = "SessionAccountNo";
        public const string SessionCustomerName = "SessionCustomerName";
        public const string SessionCustomerId = "SessionCustomerId";
        public const string SessionTinNumber = "SessionTinNumber";


        public const string SessionAddress = "SessionAddress";
        public const string SessionMobileNumber = "SessionMobileNumber";
        public const string SessionGender = "SessionGender";
        public const string SessionBrn = "SessionBrn";
        public const string SessionEmail = "SessionEmail";
        public const string SessionDOB = "SessionDOB";

        public CustomersController(CustomerDbContext context, IConfiguration configuration, IWebHostEnvironment environment)
        {
            _context = context;
            _configuration = configuration;
            this.environment = environment;
        }

        // GET: Customers
        public async Task<IActionResult> Index()
        {
            return _context.Customers != null ?
                        View(await _context.Customers.ToListAsync()) :
                        Problem("Entity set 'CustomerDbContext.Customers'  is null.");

        }

        // GET: Customers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // GET: Customers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Customers/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CustomerId,CustomerName,AccountNumber,Address,MobileNumber,Gender,Brn,DOB,Email,TinNumber")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                _context.Add(customer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }

        // GET: Customers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers.FindAsync(id);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);
        }


        // POST: Customers/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CustomerId,CustomerName,AccountNumber,Address,MobileNumber,Gender,Brn,DOB")] Customer customer)
        {
            if (id != customer.CustomerId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(customer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CustomerExists(customer.CustomerId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }


        // GET: Customers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }


        // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Customers == null)
            {
                return Problem("Entity set 'CustomerDbContext.Customers'  is null.");
            }
            var customer = await _context.Customers.FindAsync(id);
            if (customer != null)
            {
                _context.Customers.Remove(customer);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CustomerExists(int id)
        {
            return (_context.Customers?.Any(e => e.CustomerId == id)).GetValueOrDefault();
        }



        //Verify Otp add page
        //[HttpGet]
        //public IActionResult OTP(string otp)
        //{
        //    OTPManage otpManage = new OTPManage();

        //    //if (otpManage.OtpCreateTime>= DateTime.Now.AddMinutes(2)|| otpManage.OTP==)
        //    //{

        //    //}

        //    return View();
        //}

        public IActionResult OTP(string otpInput)
        {
            // Retrieve the OTP data for the current user from the database
            var userAccountNo = HttpContext.Session.GetString(SessionAccountNo);
            var otpData = _context.OTPManage.FirstOrDefault(x => x.AccountNumber == userAccountNo && x.OtpLastingTime >= DateTime.Now);

            if (otpData != null)
            {
                // Check if the entered OTP matches the stored OTP
                if (otpData.OTP==otpInput||otpData.OtpCreateTime>=DateTime.Now.AddMinutes(2))
                {
                    // OTP is correct, proceed to the next page or perform any necessary actions
                    return RedirectToAction("4");
                }
                else
                {
                    // Incorrect OTP, show an error message
                    ModelState.AddModelError("otpInput", "Invalid OTP. Please try again.");
                }
            }
            else
            {
                // OTP data not found or expired, show an error message
                ModelState.AddModelError("otpInput", "OTP expired or not available. Please request a new OTP.");
            }

            return View();
        }

        //===================OTP===========================================================
        private string GenerateOTP()
        {
            const int otpLength = 4;
            const string characters = "0123456789";
            var random = new Random();
            var otp = new char[otpLength];

            for (int i = 0; i < otpLength; i++)
            {
                otp[i] = characters[random.Next(characters.Length)];
            }
            return new string(otp);
        }

        private static string GenerateRandomKey(int keySize)
        {
            const string characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var random = new Random();
            var key = new char[keySize];

            for (int i = 0; i < keySize; i++)
            {
                key[i] = characters[random.Next(characters.Length)];
            }

            return new string(key);
        }

        //private string GenerateOTP()
        //{
        //    const int otpLength = 4;
        //    const string characters = "0123456789";
        //    var random = new Random();
        //    var otp = new char[otpLength];

        //    for (int i = 0; i < otpLength; i++)
        //    {
        //        otp[i] = characters[random.Next(characters.Length)];
        //    }

        //    string plainOTP = new string(otp);
        //    string key = GenerateRandomKey(32); // 32 bytes (256 bits) key size for HMAC-SHA256

        //    string hashedOTP = GenerateHMAC(plainOTP, key);

        //    // Optionally, you can return both the hashed OTP and the key for later validation
        //    // or you can store the key securely for validation when needed.

        //    return hashedOTP;
        //}

        //private string GenerateHMAC(string data, string key)
        //{
        //    byte[] keyBytes = Encoding.UTF8.GetBytes(key);
        //    byte[] dataBytes = Encoding.UTF8.GetBytes(data);

        //    using (HMACSHA256 hmac = new HMACSHA256(keyBytes))
        //    {
        //        byte[] hash = hmac.ComputeHash(dataBytes);
        //        return Convert.ToBase64String(hash);
        //    }
        //}
        //=======================End Time Based OTP==================================================

        //==========New Random OTP===========================================
        //private string GenerateOTP()
        //{
        //    const int otpLength = 4;
        //    const string characters = "0123456789";
        //    var random = new Random();
        //    var otp = new char[otpLength];

        //    for (int i = 0; i < otpLength; i++)
        //    {
        //        otp[i] = characters[random.Next(characters.Length)];
        //    }

        //    return new string(otp);
        //}
        //=======================End New Random OTP=================================



        //=====================Send OTP By Email===============================================
        public IActionResult SendOtpEmail()
        {
            // Save OTP to the database before sending the email
            if (ModelState.IsValid)
            {
                OTPManage otpData = new OTPManage();

                otpData.OTP = GenerateOTP();
                otpData.OtpCreateTime = DateTime.Now;
                otpData.OtpLastingTime = DateTime.Now.AddMinutes(2);
                otpData.MobileNumber = HttpContext.Session.GetString(SessionMobileNumber);
                otpData.IPADDRESS = GetIp();
                otpData.AccountNumber = HttpContext.Session.GetString(SessionAccountNo);
                _context.OTPManage.Add(otpData);
                _context.SaveChanges();

                //Send Otp to User
                //var getUserAccountNo = HttpContext.Session.GetString(SessionAccountNo); ;

                //var getOPTManager = _context.OTPManage.Where(x => x.AccountNumber == getUserAccountNo).FirstOrDefault();


                string recipientEmail = HttpContext.Session.GetString(SessionEmail);
                MailMessage Mail = new MailMessage();
                Mail.From = new MailAddress("nrb_hr@nrbbankbd.com");

                //Mail.Bcc.Add("");
                Mail.To.Add(recipientEmail);
                Mail.Subject = "One Time Password";
                Mail.Body = ("Your OTP is "+ otpData.OTP);

                SmtpClient smtp = new SmtpClient();
                smtp.UseDefaultCredentials = true;
                try
                {
                    int Message = 1;
                    smtp.Host = "10.6.9.105";
                    smtp.Port = 25;
                    smtp.Send(Mail);
                    Mail.Dispose();
                }
                catch (Exception ex)
                {
                    //throw ex.Message;
                }
            }
            return RedirectToAction("OTP");
        }
        //=====================End of Send OTP By Email===============================================


        //=====================Send OTP By SMS===============================================
        public async Task SendSMS(Customer customer)
        {
            string otp = GenerateOTP();

            string messageBody = $"Your OTP is {otp} of Account: {customer.AccountNumber}. Call: 16568";

            string sid = "NRBBL";
            string user = "nrbbl";
            string pass = "nrb@ssl";
            string URI = "http://192.168.236.2/pushapi/dynamic/server.php"; // Get the SMS URL from appsettings.json

            string myParameters = $"user={user}&pass={pass}&sms[0][0]={customer.MobileNumber}&sms[0][1]={Uri.EscapeDataString(messageBody)}&sms[0][2]={string.Empty}&sid={sid}";

            using (HttpClient httpClient = new HttpClient())
            {
                var content = new StringContent(myParameters, Encoding.ASCII, "application/x-www-form-urlencoded");
                var response = await httpClient.PostAsync(URI, content);


                //Process the response
                response.EnsureSuccessStatusCode(); // Ensure the request is successful
                string responseString = await response.Content.ReadAsStringAsync();

                // Process the response if needed
            }
        }
        //=====================End of Send OTP By SMS===============================================

        //=============================================================================ssssssssssssssss
        public async Task<IActionResult> Login(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }
            var customer = await _context.Customers
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customer == null)
            {
                return NotFound();
            }

            HttpContext.Session.SetString(SessionAccountNo, customer.AccountNumber);
            HttpContext.Session.SetString(SessionCustomerName, customer.CustomerName);
            HttpContext.Session.SetInt32(SessionCustomerId, customer.CustomerId);
            HttpContext.Session.SetString(SessionTinNumber, value: customer.TinNumber);


            HttpContext.Session.SetString(SessionAddress, customer.Address);
            HttpContext.Session.SetString(SessionMobileNumber, customer.MobileNumber);
            HttpContext.Session.SetInt32(SessionGender, customer.Gender);
            HttpContext.Session.SetString(SessionBrn, customer.Brn);
            HttpContext.Session.SetString(SessionEmail, customer.Email);

            //HttpContext.Session.SetInt32(SessionDOB, customer.DOB);


            return View(customer);

        }


        //==================================SAVE OTP===================================
        [HttpPost]
        public string SaveOtp()
        {
            if (ModelState.IsValid)
            {
                // Create a new OTPManage object
                OTPManage otpData = new OTPManage
                {
                    OTP = GenerateOTP(),
                    OtpCreateTime = DateTime.Now,
                    CustomerId = Convert.ToInt32(HttpContext.Session.GetString(SessionCustomerId)),
                    OtpLastingTime = DateTime.Now.AddMinutes(2), // You can set the OtpTime property to the current date and time
                    MobileNumber = HttpContext.Session.GetString(SessionMobileNumber),
                    IPADDRESS = GetIp(),
                    AccountNumber = HttpContext.Session.GetString(SessionAccountNo)
                };
                _context.OTPManage.Add(otpData);
                _context.SaveChanges();
                return "MESSEGE SEND SUCCESSFULLY";
            }
            else
            {
                return "MESSEGE SENDING FAILED";
            }
        }

        public IActionResult ViewDocuments(string searchString, DateTime? fromDate, DateTime? toDate, string sortColumn, string sortDirection, int page = 1)
        {
            int pageSize = 2; // Number of items per page

            var documents = _context.CustomerDocuments.AsQueryable(); // Get all documents

            // Apply search filters
            if (!string.IsNullOrEmpty(searchString))
            {
                documents = documents.Where(d =>
                    d.CustomerName.Contains(searchString) ||
                    d.TinNumber == searchString);
            }

            if (fromDate.HasValue)
            {
                documents = documents.Where(d => d.ProcessDate >= fromDate);
            }

            if (toDate.HasValue)
            {
                documents = documents.Where(d => d.ProcessDate <= toDate);
            }

            // Apply sorting
            switch (sortColumn)
            {
                case "customerName":
                    documents = (sortDirection == "asc")
                        ? documents.OrderBy(d => d.CustomerName)
                        : documents.OrderByDescending(d => d.CustomerName);
                    break;
                case "assessmentYear":
                    documents = (sortDirection == "asc")
                        ? documents.OrderBy(d => d.AssesmentYear)
                        : documents.OrderByDescending(d => d.AssesmentYear);
                    break;
                // Add more cases for other columns as needed
                default:
                    documents = documents.OrderByDescending(d => d.ProcessDate);
                    break;
            }

            // Paging
            var totalItems = documents.Count();
            var totalPages = (int)Math.Ceiling(totalItems / (double)pageSize);
            var paginatedDocuments = documents.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            ViewBag.PageSize = pageSize;
            ViewBag.TotalItems = totalItems;
            ViewBag.TotalPages = totalPages;
            ViewBag.CurrentPage = page;

            return View(paginatedDocuments);
        }



        public IActionResult AddDocument()
        {
            VMCustomerDocument objVMCustomerDocument = new VMCustomerDocument();

            objVMCustomerDocument.AccountNumber = HttpContext.Session.GetString(SessionAccountNo);
            objVMCustomerDocument.CustomerName = HttpContext.Session.GetString(SessionCustomerName);
            objVMCustomerDocument.CustomerId = HttpContext.Session.GetInt32(SessionCustomerId) ?? 0;
            objVMCustomerDocument.TinNumber = HttpContext.Session.GetString(SessionTinNumber);

            objVMCustomerDocument.Address = HttpContext.Session.GetString(SessionAddress);
            objVMCustomerDocument.MobileNumber = HttpContext.Session.GetString(SessionMobileNumber);
            objVMCustomerDocument.Brn = HttpContext.Session.GetString(SessionBrn);
            objVMCustomerDocument.Email = HttpContext.Session.GetString(SessionEmail);
            //objVMCustomerDocument.DOB=HttpContext.Session.GetString(SessionDOB);
            objVMCustomerDocument.Gender = HttpContext.Session.GetInt32(SessionGender);

            ViewBag.AccountNumber = objVMCustomerDocument.AccountNumber;
            ViewBag.CustomerName = objVMCustomerDocument.CustomerName;
            ViewBag.CustomerId = objVMCustomerDocument.CustomerId;
            ViewBag.TinNumber = objVMCustomerDocument.TinNumber;
            ViewBag.Address = objVMCustomerDocument.Address;
            ViewBag.MobileNumber = objVMCustomerDocument.MobileNumber;
            ViewBag.Gender = objVMCustomerDocument.Gender;
            ViewBag.Brn = objVMCustomerDocument.Brn;
            ViewBag.Email = objVMCustomerDocument.Email;


            return View(objVMCustomerDocument);
        }


        //=========================================================
        //file upload verification to account number against AccesmentYear
        [HttpPost]
        public IActionResult AddDocument(VMCustomerDocument model)
        {
            //CustomerDocument cd = new CustomerDocument();
            // Check if the user has already uploaded a document for the same assessment year

            //var existingDocument = cd.AccountNumber == model.AccountNumber && cd.AssesmentYear == model.AssesmentYear;

            if (ModelState.IsValid)
            {

            }
            var existingDocument = _context.CustomerDocuments
                .FirstOrDefault(cd => cd.CustomerId.ToString() == model.CustomerId.ToString() && cd.AssesmentYear == model.AssesmentYear);
            if (existingDocument != null)
            {
                TempData["ErrorMessage"] = "You have already uploaded a document for the same assessment year.";
                return View("SessionYearError");
            }
            else
            {
                // Check if a file is uploaded
                if (model.Document != null && model.Document.Length > 0)
                {
                    string webRoot = environment.WebRootPath;
                    string folder = "Images";
                    string fileName = Guid.NewGuid().ToString();
                    string fileExtension = Path.GetExtension(model.Document.FileName);
                    string fileToWrite;
                    string newFilePath;
                    if (fileExtension.ToLower() == ".pdf")
                    {
                        // Check PDF file size (200 KB limit)
                        if (model.Document.Length > 200 * 1024)
                        {
                            TempData["ErrorMessage"] = "Invalid file size. PDF files should be up to 200 KB.";
                            return View();
                        }
                        fileToWrite = Path.Combine(webRoot, folder, fileName + fileExtension);
                        newFilePath = Path.Combine(folder, fileName + fileExtension);
                    }
                    else if (IsImageFileExtension(fileExtension.ToLower()))
                    {
                        // Check image file size (100 KB limit)
                        if (model.Document.Length > 100 * 1024)
                        {
                            TempData["ErrorMessage"] = "Invalid file size.Image files should be up to 100 KB.";
                            return View();
                        }
                        fileToWrite = Path.Combine(webRoot, folder, fileName + fileExtension);
                        newFilePath = Path.Combine(folder, fileName + fileExtension);
                    }
                    else
                    {
                        // Invalid file type, handle accordingly (e.g., show an error message)
                        TempData["ErrorMessage"] = "Invalid file type. Only PDF and image files are allowed.";
                        return View();
                    }
                    using (var stream = new FileStream(fileToWrite, FileMode.Create))
                    {
                        model.Document.CopyTo(stream);
                    }
                    var tinNumber = HttpContext.Session.GetString(SessionTinNumber); // Get the existing tinNumber value from the session

                    if (model.TinNumber != tinNumber) // Check if the new tinNumber is different from the existing value
                    {
                        HttpContext.Session.SetString(SessionTinNumber, model.TinNumber); // Update the session value with the new tinNumber
                    }

                    var ipnumber = Dns.GetHostEntry(Dns.GetHostName()).AddressList.FirstOrDefault(x => x.AddressFamily == AddressFamily.InterNetwork)?.ToString();


                    //var ipAddress = ipnumber.
                    var customerDocument = new CustomerDocument
                    {
                        CustomerId = (int)HttpContext.Session.GetInt32(SessionCustomerId),
                        //CustomerId = model.CustomerId,
                        CustomerName = HttpContext.Session.GetString(SessionCustomerName),
                        //AccountNumber = HttpContext.Session.GetString(SessionAccountNo),
                        AccountNumber = MaskAccountNumber(HttpContext.Session.GetString(SessionAccountNo)),
                        //TinNumber = model.TinNumber,
                        TinNumber = HttpContext.Session.GetString(SessionTinNumber),// Use the updated TinNumber value from the session
                        AssesmentYear = model.AssesmentYear,
                        Reference = model.Reference,
                        RefNumber = model.RefNumber,
                        Document = newFilePath,
                        SubIP = GetIp(),
                        SubmissionDate = DateTime.Now,
                        Status = 0.ToString(),
                        ProcessDate = DateTime.Now,
                        ProcessIP = GetIp(),
                        //ProcessUser=
                    };
                    _context.CustomerDocuments.Add(customerDocument);
                    _context.SaveChanges();
                    return RedirectToAction("FeedBack");
                }
                // No file uploaded, handle accordingly (e.g., show an error message)
                TempData["ErrorMessage"] = "No file uploaded.";
                return View();
            }
        }

        private string GetIp()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            var ipAddresses = new List<string>();

            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    ipAddresses.Add(ip.ToString());
                }
            }

            string ip2 = Dns.GetHostEntry(Dns.GetHostName()).AddressList.FirstOrDefault(x => x.AddressFamily == AddressFamily.InterNetwork)?.ToString();
            if (ip2 != null)
            {
                ipAddresses.Add(ip2);
                // Assign the value of ip2 to the SubIP field
            }

            return ipAddresses.FirstOrDefault(); // Return the first IP address from the list, or null if the list is empty
        }

        //MaskAccountNumber
        private string MaskAccountNumber(string accountNumber)
        {
            if (!string.IsNullOrEmpty(accountNumber) && accountNumber.Length > 10)
            {
                var maskedAccountNumber = accountNumber.Substring(0, 6) + new string('*', accountNumber.Length - 10) + accountNumber.Substring(accountNumber.Length - 4);
                return maskedAccountNumber;
            }

            return accountNumber;
        }

        private bool IsImageFileExtension(string fileExtension)
        {
            string[] imageExtensions = { ".jpg", ".jpeg", ".png", ".gif" }; // Add more image file extensions if needed

            return imageExtensions.Contains(fileExtension);
        }


        //Document upload success view 
        public IActionResult FeedBack()
        {
            return View();
        }

        //Session Year Document upload error view 
        public IActionResult SessionYearError()
        {
            return View();
        }




        private bool verifyOtp(string enterdOtp, string generateOtp)
        {
            return enterdOtp.Equals(generateOtp);
        }




        [HttpPost]
        public IActionResult SubmitOtp([FromForm] int finalDigit)
        {
            int a = Convert.ToInt32(TempData["otp"]);
            if (finalDigit == null)
            {
                return NoContent();
            }

            else if ((DateTime.Now - Convert.ToDateTime(TempData["timestamp"])).TotalMinutes > 30)
            {
                return BadRequest("OTP Timedout");
            }
            else if (finalDigit.ToString() == Convert.ToString(a))
            {
                return Ok("OTP Accepted");
            }
            else
            {
                return BadRequest("Please Enter Valid OTP");
            }
        }




        [HttpPost]
        public IActionResult VerifyOTP(OtpVerificationOptions model)
        {
            if (ModelState.IsValid)
            {
                if (TempData.TryGetValue("OTP", out object otp) &&
                    TempData.TryGetValue("MobileNumber", out object mobileNumber) &&
                    otp.ToString() == model.OTP && mobileNumber.ToString() == model.MobileNumber)
                {
                    TempData.Remove("OTP");
                    TempData.Remove("MobileNumber");

                    ViewBag.SuccessMessage = "OTP verification successful!";
                    return View();
                }

                ModelState.AddModelError("", "Invalid OTP");
            }
            return View(/*model*/);
        }

        


        public async Task<IActionResult> ViewCustomerDetails(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers
                .FirstOrDefaultAsync(m => m.CustomerId == id);

            if (customer == null)
            {
                return NotFound();
            }

            // Retrieve the latest CustomerDocument for the customer
            var latestCustomerDocument = await _context.CustomerDocuments
                .Where(cd => cd.CustomerId == id)
                .OrderByDescending(cd => cd.SubmissionDate)
                .FirstOrDefaultAsync();

            // Populate the VMCustomerDetails model
            var viewModel = new VMCustomerDetails
            {
                // Customer Properties
                CustomerId = customer.CustomerId,
                CustomerName = customer.CustomerName,
                AccountNumber = customer.AccountNumber,
                Address = customer.Address,
                MobileNumber = customer.MobileNumber,
                TinNumber = customer.TinNumber,
                Gender = customer.Gender,
                Brn = customer.Brn,
                Email = customer.Email,
                DOB = customer.DOB,
                // CustomerDocument Properties
                //CustomerDocumentId = latestCustomerDocument?.CustomerDocumentId ?? 0,
                AssesmentYear = latestCustomerDocument?.AssesmentYear ?? 0,
                DocumentPath = latestCustomerDocument?.Document,
                Reference = latestCustomerDocument?.Reference,
                RefNumber = latestCustomerDocument?.RefNumber,
                SubmissionDate = latestCustomerDocument?.SubmissionDate,
                SubUser = latestCustomerDocument?.SubUser,
                SubIP = latestCustomerDocument?.SubIP,
                ProcessDate = latestCustomerDocument?.ProcessDate,
                ProcessUser = latestCustomerDocument?.ProcessUser,
                ProcessIP = latestCustomerDocument?.ProcessIP,
                Status = latestCustomerDocument?.Status,
                Remark = latestCustomerDocument?.Remark,
                Location = latestCustomerDocument?.Location,
                BF1 = latestCustomerDocument?.BF1,
                BF2 = latestCustomerDocument?.BF2,
                BF3 = latestCustomerDocument?.BF3,
                BF4 = latestCustomerDocument?.BF4,
                BF5 = latestCustomerDocument?.BF5,
                BF6 = latestCustomerDocument?.BF6
            };
            return View(viewModel);
        }
    }
}





//Save OTP in database by encrypted
//Then send otp by decrypted
//Then verify otp 


