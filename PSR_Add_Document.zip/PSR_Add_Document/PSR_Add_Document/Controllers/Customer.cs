﻿namespace PSR_Add_Document.Controllers
{
    //internal class Customer<T1, T2> : IEnumerable<string>
    //{
    //}
}