﻿namespace PSR_Add_Document.Models.Models
{
    public class Audit
    {
        public DateTime LoginInDate { get; set; }
        public int EmpId { get; set; } 
        
    }
}
