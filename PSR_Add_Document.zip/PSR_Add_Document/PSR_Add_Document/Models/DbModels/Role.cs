﻿namespace PSR_Add_Document.Models.Models
{
    public class Role
    {
        public int RoleID { get; set; }
        public string UserRole { get; set; }
    }
}
